import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

const FloatingElements: React.FC = () => {
  const [windowSize, setWindowSize] = useState({ width: 1200, height: 800 });

  useEffect(() => {
    const updateWindowSize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    updateWindowSize();
    window.addEventListener('resize', updateWindowSize);
    return () => window.removeEventListener('resize', updateWindowSize);
  }, []);

  const elements = [
    { size: 'w-4 h-4', color: 'bg-blue-500', delay: 0 },
    { size: 'w-6 h-6', color: 'bg-purple-500', delay: 2 },
    { size: 'w-3 h-3', color: 'bg-pink-500', delay: 4 },
    { size: 'w-5 h-5', color: 'bg-cyan-500', delay: 1 },
    { size: 'w-4 h-4', color: 'bg-indigo-500', delay: 3 },
  ];

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {elements.map((element, index) => (
        <motion.div
          key={index}
          className={`absolute ${element.size} ${element.color} rounded-full opacity-20`}
          initial={{
            x: Math.random() * windowSize.width,
            y: windowSize.height + 100,
          }}
          animate={{
            y: -100,
            x: Math.random() * windowSize.width,
          }}
          transition={{
            duration: Math.random() * 10 + 10,
            repeat: Infinity,
            delay: element.delay,
            ease: 'linear',
          }}
        />
      ))}
    </div>
  );
};

export default FloatingElements;