import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ScrollReveal from './ScrollReveal';

const InteractiveDemo: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);
  
  const steps = [
    {
      title: 'Connect Your Data',
      description: 'Seamlessly integrate with your existing systems and data sources',
      icon: '🔗',
      color: 'from-blue-500 to-cyan-500',
    },
    {
      title: 'AI Analysis',
      description: 'Our advanced AI algorithms analyze patterns and optimize workflows',
      icon: '🧠',
      color: 'from-purple-500 to-pink-500',
    },
    {
      title: 'Automated Actions',
      description: 'Watch as intelligent agents execute tasks with precision and speed',
      icon: '⚡',
      color: 'from-green-500 to-teal-500',
    },
    {
      title: 'Real-time Results',
      description: 'Monitor performance and see immediate improvements in efficiency',
      icon: '📊',
      color: 'from-orange-500 to-red-500',
    },
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <ScrollReveal>
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              See ZapAgent AI
              <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                {' '}In Action
              </span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Experience the power of intelligent automation through our interactive demonstration
            </p>
          </div>
        </ScrollReveal>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Steps Navigation */}
          <div className="space-y-4">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                className={`p-6 rounded-2xl cursor-pointer transition-all duration-300 ${
                  activeStep === index
                    ? 'bg-white/10 border border-white/20'
                    : 'bg-black/20 border border-white/5 hover:bg-white/5'
                }`}
                onClick={() => setActiveStep(index)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="flex items-center space-x-4">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${step.color} flex items-center justify-center text-xl`}>
                    {step.icon}
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-lg">{step.title}</h3>
                    <p className="text-gray-400 text-sm">{step.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Demo Visualization */}
          <div className="relative">
            <div className="bg-black/40 backdrop-blur-xl rounded-3xl border border-white/10 p-8 h-96">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeStep}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.5 }}
                  className="h-full flex flex-col items-center justify-center text-center"
                >
                  <div className={`w-24 h-24 rounded-full bg-gradient-to-r ${steps[activeStep].color} flex items-center justify-center text-4xl mb-6`}>
                    {steps[activeStep].icon}
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-4">
                    {steps[activeStep].title}
                  </h3>
                  <p className="text-gray-300 text-lg">
                    {steps[activeStep].description}
                  </p>
                  
                  {/* Animated progress bar */}
                  <div className="w-full bg-white/10 rounded-full h-2 mt-8">
                    <motion.div
                      className={`h-2 rounded-full bg-gradient-to-r ${steps[activeStep].color}`}
                      initial={{ width: 0 }}
                      animate={{ width: '100%' }}
                      transition={{ duration: 2, repeat: Infinity }}
                    />
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default InteractiveDemo;