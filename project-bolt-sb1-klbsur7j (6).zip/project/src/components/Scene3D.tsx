import React, { Suspense } from 'react';

const Scene3D: React.FC = () => {
  return (
    <div className="fixed inset-0 -z-10 pointer-events-none">
      <Suspense fallback={null}>
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/20 via-transparent to-purple-50/20" />
        
        {/* Floating Elements */}
        <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-blue-400/10 rounded-full blur-2xl animate-float" />
        <div className="absolute bottom-1/3 right-1/4 w-40 h-40 bg-purple-400/10 rounded-full blur-2xl animate-float" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 right-1/3 w-24 h-24 bg-cyan-400/10 rounded-full blur-xl animate-float" style={{ animationDelay: '4s' }} />
      </Suspense>
    </div>
  );
};

export default Scene3D;