import React from 'react';
import { motion } from 'framer-motion';
import ScrollReveal from './ScrollReveal';

const TechGrid: React.FC = () => {
  const technologies = [
    { name: 'Machine Learning', icon: '🧠', color: 'from-blue-500 to-cyan-500' },
    { name: 'Neural Networks', icon: '🕸️', color: 'from-purple-500 to-pink-500' },
    { name: 'Natural Language', icon: '💬', color: 'from-green-500 to-teal-500' },
    { name: 'Computer Vision', icon: '👁️', color: 'from-orange-500 to-red-500' },
    { name: 'Deep Learning', icon: '🔬', color: 'from-indigo-500 to-purple-500' },
    { name: 'Automation', icon: '⚡', color: 'from-yellow-500 to-orange-500' },
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <ScrollReveal>
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Powered by
              <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                {' '}Advanced AI
              </span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Our cutting-edge technology stack delivers unparalleled performance and intelligence
            </p>
          </div>
        </ScrollReveal>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {technologies.map((tech, index) => (
            <ScrollReveal key={index} delay={index * 0.1}>
              <motion.div
                className="relative group"
                whileHover={{ y: -10 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="absolute inset-0 bg-gradient-to-r opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl blur-xl"
                     style={{ background: `linear-gradient(135deg, ${tech.color.split(' ')[1]}, ${tech.color.split(' ')[3]})` }} />
                
                <div className="relative bg-black/40 backdrop-blur-xl rounded-2xl border border-white/10 p-8 text-center group-hover:border-white/30 transition-all duration-300">
                  <div className="text-4xl mb-4">{tech.icon}</div>
                  <h3 className="text-white font-semibold text-lg">{tech.name}</h3>
                </div>
              </motion.div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TechGrid;