import React from 'react';
import { motion } from 'framer-motion';
import AnimatedCounter from './AnimatedCounter';
import ScrollReveal from './ScrollReveal';

const Stats = () => {
  const stats = [
    { number: 10000000, label: 'Automations Executed', suffix: '+', prefix: '' },
    { number: 99.9, label: 'Uptime Guarantee', suffix: '%', prefix: '' },
    { number: 500, label: 'Enterprise Clients', suffix: '+', prefix: '' },
    { number: 24, label: 'AI Support', suffix: '/7', prefix: '' }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="relative">
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-600/20 rounded-3xl blur-3xl"
            animate={{ 
              scale: [1, 1.02, 1],
              opacity: [0.3, 0.6, 0.3]
            }}
            transition={{ duration: 4, repeat: Infinity }}
          />
          <div className="relative bg-black/40 backdrop-blur-xl rounded-3xl border border-white/10 p-12">
            <ScrollReveal>
              <div className="text-center mb-12">
                <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
                  Trusted by Industry Leaders
                </h2>
                <p className="text-xl text-gray-300 max-w-2xl mx-auto">
                  Join thousands of companies already transforming their operations with ZapAgent AI
                </p>
              </div>
            </ScrollReveal>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <ScrollReveal key={index} delay={index * 0.1}>
                  <div className="text-center">
                    <div className="mb-2">
                      <AnimatedCounter 
                        end={stat.number} 
                        suffix={stat.suffix}
                        prefix={stat.prefix}
                      />
                    </div>
                    <div className="text-gray-400 text-sm md:text-base">{stat.label}</div>
                  </div>
                </ScrollReveal>
              ))}
            </div>

            <ScrollReveal delay={0.6}>
              <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 opacity-60">
                {['TechCorp', 'InnovateLab', 'FutureScale', 'DataFlow'].map((company, index) => (
                  <motion.div 
                    key={index}
                    className="flex items-center justify-center"
                    whileHover={{ scale: 1.1, opacity: 1 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <div className="text-white font-bold text-xl">{company}</div>
                  </motion.div>
                ))}
              </div>
            </ScrollReveal>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Stats;