import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface MicroButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary';
  className?: string;
  href?: string;
}

export const MicroButton: React.FC<MicroButtonProps> = ({
  children,
  onClick,
  variant = 'primary',
  className = '',
  href,
}) => {
  const [isHovered, setIsHovered] = useState(false);

  const buttonContent = (
    <motion.button
      className={`relative overflow-hidden rounded-xl font-medium transition-all duration-300 group ${
        variant === 'primary'
          ? 'bg-gray-900 dark:bg-white text-white dark:text-gray-900 px-6 py-3 text-sm shadow-sm border border-gray-900 dark:border-white'
          : 'border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 px-6 py-3 bg-white dark:bg-gray-800'
      } ${className}`}
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ 
        scale: 1.02,
        y: -1,
      }}
      whileTap={{ 
        scale: 0.98,
        y: 0
      }}
      transition={{ 
        type: "spring", 
        stiffness: 400, 
        damping: 25
      }}
    >
      {/* Subtle background glow on hover */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-xl opacity-0"
        animate={{ 
          opacity: isHovered ? 1 : 0,
        }}
        transition={{ duration: 0.3 }}
      />
      
      {/* Clean shimmer effect */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent w-full"
        initial={{ x: '-100%' }}
        animate={{ x: isHovered ? '100%' : '-100%' }}
        transition={{ duration: 0.6, ease: "easeInOut" }}
      />
      
      {/* Content */}
      <span className="relative z-10 flex items-center justify-center">
        {children}
      </span>

      {/* Subtle border enhancement on hover */}
      <motion.div
        className="absolute inset-0 rounded-xl border border-gray-200 dark:border-gray-700 opacity-0"
        animate={{
          opacity: isHovered ? 1 : 0,
        }}
        transition={{ duration: 0.2 }}
      />
    </motion.button>
  );

  if (href) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className="inline-block">
        {buttonContent}
      </a>
    );
  }

  return buttonContent;
};

interface MicroCardProps {
  children: React.ReactNode;
  className?: string;
}

export const MicroCard: React.FC<MicroCardProps> = ({ children, className = '' }) => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePosition({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
  };

  return (
    <motion.div
      className={`relative overflow-hidden rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 ${className}`}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ 
        y: -8,
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)'
      }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      {/* Glow effect */}
      <motion.div
        className="absolute inset-0 opacity-0 transition-opacity duration-300"
        style={{
          background: `radial-gradient(600px circle at ${mousePosition.x}px ${mousePosition.y}px, rgba(59, 130, 246, 0.1), transparent 40%)`,
        }}
        animate={{ opacity: isHovered ? 1 : 0 }}
      />
      
      {/* Border glow */}
      <motion.div
        className="absolute inset-0 rounded-2xl"
        animate={{
          boxShadow: isHovered 
            ? '0 0 20px rgba(59, 130, 246, 0.3)' 
            : '0 0 0px rgba(59, 130, 246, 0)'
        }}
        transition={{ duration: 0.3 }}
      />
      
      <div className="relative z-10">
        {children}
      </div>
    </motion.div>
  );
};

interface FloatingElementProps {
  children: React.ReactNode;
  delay?: number;
  amplitude?: number;
}

export const FloatingElement: React.FC<FloatingElementProps> = ({ 
  children, 
  delay = 0,
  amplitude = 20 
}) => {
  return (
    <motion.div
      animate={{
        y: [0, -amplitude, 0],
        rotate: [0, 2, -2, 0],
      }}
      transition={{
        duration: 4,
        repeat: Infinity,
        delay,
        ease: "easeInOut",
      }}
    >
      {children}
    </motion.div>
  );
};