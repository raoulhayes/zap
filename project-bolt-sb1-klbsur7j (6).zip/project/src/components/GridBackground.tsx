import React from 'react';

const GridBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 -z-10">
      {/* Enhanced Grid Pattern */}
      <div 
        className="absolute inset-0 opacity-[0.03] dark:opacity-[0.05]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(59, 130, 246, 0.15) 1px, transparent 1px),
            linear-gradient(90deg, rgba(59, 130, 246, 0.15) 1px, transparent 1px),
            linear-gradient(rgba(139, 92, 246, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(139, 92, 246, 0.1) 1px, transparent 1px)
          `,
          backgroundSize: '32px 32px, 32px 32px, 128px 128px, 128px 128px'
        }}
      />
      
      {/* Enhanced Gradient Overlays */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50/40 via-transparent to-purple-50/40 dark:from-blue-900/20 dark:via-transparent dark:to-purple-900/20" />
      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/20 dark:via-gray-900/20 to-transparent" />
      
      {/* Subtle Animated Glow */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-400/5 dark:bg-blue-400/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-400/5 dark:bg-purple-400/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
    </div>
  );
};

export default GridBackground;