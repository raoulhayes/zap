import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const ProductDemo: React.FC = () => {
  const { ref, inView } = useInView({ threshold: 0.1, triggerOnce: true });
  const [activeTab, setActiveTab] = useState(0);

  const demos = [
    {
      title: 'Customer Support Agent',
      description: 'AI agent that handles customer inquiries, escalates complex issues, and maintains conversation context.',
      metrics: { accuracy: '96%', response: '2.3s', satisfaction: '4.8/5' },
      code: `// Deploy a customer support agent
const agent = new ZapAgent({
  model: 'gpt-4',
  role: 'customer-support',
  knowledge: './support-docs',
  integrations: ['zendesk', 'slack']
});

agent.deploy();`
    },
    {
      title: 'Data Processing Pipeline',
      description: 'Automated data ingestion, transformation, and analysis with intelligent error handling.',
      metrics: { throughput: '10M/hr', accuracy: '99.2%', cost: '-67%' },
      code: `// Create data processing pipeline
const pipeline = new ZapAgent({
  model: 'claude-3',
  role: 'data-processor',
  sources: ['s3', 'postgres', 'api'],
  outputs: ['warehouse', 'dashboard']
});

pipeline.schedule('0 */6 * * *');`
    },
    {
      title: 'Sales Qualification Bot',
      description: 'Intelligent lead qualification and routing with personalized follow-up sequences.',
      metrics: { conversion: '+34%', speed: '10x', leads: '2.4K/mo' },
      code: `// Deploy sales qualification agent
const salesBot = new ZapAgent({
  model: 'gpt-4-turbo',
  role: 'sales-qualifier',
  crm: 'salesforce',
  scoring: 'custom-model'
});

salesBot.enableWebhooks();`
    }
  ];

  return (
    <section ref={ref} className="py-24 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-gray-800 transition-colors duration-500">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            See ZapAgent in
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> action</span>
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Real examples of AI agents deployed in production environments
          </p>
        </motion.div>

        <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
          <div className="border-b border-gray-200 dark:border-gray-700">
            <nav className="flex">
              {demos.map((demo, index) => (
                <button
                  key={index}
                  onClick={() => setActiveTab(index)}
                  className={`flex-1 px-6 py-4 text-sm font-medium transition-colors ${
                    activeTab === index
                      ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400 bg-blue-50 dark:bg-blue-900/30'
                      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                >
                  {demo.title}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
              >
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                    {demos[activeTab].title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-8 text-lg leading-relaxed">
                    {demos[activeTab].description}
                  </p>
                  
                  <div className="grid grid-cols-3 gap-6">
                    {Object.entries(demos[activeTab].metrics).map(([key, value], index) => (
                      <div key={index} className="text-center">
                        <div className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{value}</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400 capitalize">{key}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-gray-900 dark:bg-gray-800 rounded-2xl p-6 overflow-hidden border border-gray-700">
                  <div className="flex items-center space-x-2 mb-4">
                    <div className="w-3 h-3 bg-red-400 rounded-full" />
                    <div className="w-3 h-3 bg-yellow-400 rounded-full" />
                    <div className="w-3 h-3 bg-green-400 rounded-full" />
                    <span className="text-gray-400 text-sm ml-4">agent.js</span>
                  </div>
                  <pre className="text-green-400 text-sm font-mono leading-relaxed overflow-x-auto">
                    {demos[activeTab].code}
                  </pre>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProductDemo;