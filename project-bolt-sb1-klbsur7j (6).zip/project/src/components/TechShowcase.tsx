import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const TechShowcase: React.FC = () => {
  const { ref, inView } = useInView({ threshold: 0.1, triggerOnce: true });

  const technologies = [
    { name: 'GPT-4', category: 'Language Models', logo: '🧠' },
    { name: 'Claude', category: 'Reasoning', logo: '🤖' },
    { name: 'Gemini', category: 'Multimodal', logo: '💎' },
    { name: 'LangChain', category: 'Orchestration', logo: '🔗' },
    { name: 'Vector DB', category: 'Memory', logo: '🗄️' },
    { name: 'Kubernetes', category: 'Infrastructure', logo: '☸️' },
  ];

  return (
    <section ref={ref} className="py-24 px-4 sm:px-6 lg:px-8 bg-white dark:bg-gray-900 transition-colors duration-500">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Powered by the
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> latest AI</span>
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Built on cutting-edge AI models and enterprise-grade infrastructure
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {technologies.map((tech, index) => (
            <motion.div
              key={index}
              className="bg-white dark:bg-gray-800 rounded-2xl p-6 text-center border border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 hover:shadow-lg transition-all duration-300 group"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              <div className="text-3xl mb-4 group-hover:scale-110 transition-transform">
                {tech.logo}
              </div>
              <h3 className="font-semibold text-gray-900 dark:text-white mb-1">{tech.name}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">{tech.category}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          className="mt-16 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-3xl p-12 text-center border border-blue-100 dark:border-blue-800/30"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Enterprise-Ready Architecture
          </h3>
          <p className="text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
            Multi-region deployment, 99.99% uptime SLA, and automatic failover 
            ensure your AI agents are always available when you need them.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { metric: '99.99%', label: 'Uptime SLA' },
              { metric: '<50ms', label: 'Response Time' },
              { metric: '24/7', label: 'Monitoring' }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl font-bold text-gray-900 dark:text-white mb-2">{item.metric}</div>
                <div className="text-gray-600 dark:text-gray-400">{item.label}</div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default TechShowcase;