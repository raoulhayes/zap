import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const ProcessFlow: React.FC = () => {
  const { ref, inView } = useInView({ threshold: 0.1, triggerOnce: true });

  const steps = [
    {
      id: 1,
      title: 'Connect & Integrate',
      description: 'Seamlessly connect your data sources, APIs, and existing tools',
      icon: '🔗',
      color: 'from-blue-500 to-cyan-500',
      details: ['Multi-source Integration', 'API Orchestration', 'Data Pipeline Setup']
    },
    {
      id: 2,
      title: 'AI Intelligence Layer',
      description: 'Deploy advanced AI models with intelligent decision workflows',
      icon: '🧠',
      color: 'from-purple-500 to-pink-500',
      details: ['Model Deployment', 'Decision Trees', 'Smart Routing']
    },
    {
      id: 3,
      title: 'Automated Execution',
      description: 'Launch intelligent agents with auto-scaling infrastructure',
      icon: '🚀',
      color: 'from-green-500 to-teal-500',
      details: ['Agent Deployment', 'Auto-Scaling', 'Load Distribution']
    },
    {
      id: 4,
      title: 'Performance Analytics',
      description: 'Monitor and optimize with comprehensive real-time analytics',
      icon: '📊',
      color: 'from-orange-500 to-red-500',
      details: ['Performance Monitoring', 'Optimization', 'Predictive Insights']
    }
  ];

  return (
    <section ref={ref} className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          className="text-center mb-20"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            How ZapAgent
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Works</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From integration to automation - deploy intelligent agents in four simple steps.
          </p>
        </motion.div>

        {/* Process Flow Visualization */}
        <div className="relative">
          {/* Connection Lines */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-blue-200 via-purple-200 via-green-200 to-orange-200 transform -translate-y-1/2 z-0" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
            {steps.map((step, index) => (
              <motion.div
                key={step.id}
                className="relative"
                initial={{ opacity: 0, y: 50 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.2 }}
              >
                {/* Step Number */}
                <div className="flex justify-center mb-6">
                  <motion.div 
                    className={`w-20 h-20 rounded-2xl bg-gradient-to-r ${step.color} flex items-center justify-center text-white font-bold text-2xl shadow-lg relative overflow-hidden`}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <div className="absolute inset-0 bg-white/20 transform -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                    <span className="relative z-10">{step.id}</span>
                  </motion.div>
                </div>

                {/* Card */}
                <motion.div
                  className="bg-white/90 backdrop-blur-xl rounded-2xl p-8 shadow-lg border border-white/20 hover:shadow-2xl transition-all duration-300 group relative overflow-hidden"
                  whileHover={{ y: -10, scale: 1.02 }}
                >
                  <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-purple-500 via-green-500 to-orange-500" />
                  
                  <div className="text-center mb-6">
                    <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">
                      {step.icon}
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{step.title}</h3>
                    <p className="text-gray-600">{step.description}</p>
                  </div>

                  <ul className="space-y-3">
                    {step.details.map((detail, detailIndex) => (
                      <motion.li 
                        key={detailIndex} 
                        className="flex items-center text-sm text-gray-500"
                        initial={{ opacity: 0, x: -10 }}
                        animate={inView ? { opacity: 1, x: 0 } : {}}
                        transition={{ delay: (index * 0.2) + (detailIndex * 0.1) }}
                      >
                        <div className={`w-3 h-3 rounded-sm bg-gradient-to-r ${step.color} mr-3 flex-shrink-0`} />
                        {detail}
                      </motion.li>
                    ))}
                  </ul>
                </motion.div>

                {/* Arrow for mobile */}
                {index < steps.length - 1 && (
                  <div className="lg:hidden flex justify-center mt-8">
                    <motion.svg 
                      className="w-6 h-6 text-gray-400" 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                      animate={{ y: [0, 5, 0] }}
                      transition={{ repeat: Infinity, duration: 2 }}
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                    </motion.svg>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProcessFlow;