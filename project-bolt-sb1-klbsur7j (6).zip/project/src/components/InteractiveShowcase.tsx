import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const InteractiveShowcase: React.FC = () => {
  const { ref, inView } = useInView({ threshold: 0.1, triggerOnce: true });
  const [activeDemo, setActiveDemo] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  const demos = [
    {
      title: 'Customer Support Automation',
      description: 'Watch how our AI agent handles customer inquiries with human-like understanding',
      steps: [
        'Customer sends inquiry',
        'AI analyzes intent & context',
        'Searches knowledge base',
        'Provides personalized response',
        'Escalates if needed'
      ],
      metrics: { 'Response Time': '2.3s', 'Accuracy': '96%', 'Satisfaction': '4.8/5' }
    },
    {
      title: 'Sales Lead Qualification',
      description: 'See how intelligent agents qualify and route leads automatically',
      steps: [
        'Lead enters system',
        'AI scores lead quality',
        'Enriches with data',
        'Routes to best rep',
        'Schedules follow-up'
      ],
      metrics: { 'Conversion Rate': '+34%', 'Speed': '10x faster', 'Accuracy': '92%' }
    },
    {
      title: 'Data Processing Pipeline',
      description: 'Experience automated data transformation and analysis in real-time',
      steps: [
        'Data ingestion starts',
        'AI validates quality',
        'Transforms & cleanses',
        'Generates insights',
        'Updates dashboards'
      ],
      metrics: { 'Throughput': '10M/hr', 'Accuracy': '99.2%', 'Cost Savings': '67%' }
    }
  ];

  const playDemo = () => {
    setIsPlaying(true);
    setTimeout(() => setIsPlaying(false), 5000);
  };

  return (
    <section ref={ref} className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            See ZapAgent
            <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent"> In Action</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Interactive demonstrations of real AI agents solving business challenges
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Demo Selection */}
          <div className="space-y-4">
            {demos.map((demo, index) => (
              <motion.div
                key={index}
                className={`p-6 rounded-2xl cursor-pointer transition-all duration-300 backdrop-blur-xl border ${
                  activeDemo === index
                    ? 'bg-white/20 border-white/30 shadow-xl'
                    : 'bg-white/5 border-white/10 hover:bg-white/10'
                }`}
                onClick={() => setActiveDemo(index)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                initial={{ opacity: 0, x: -50 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <h3 className="text-white font-semibold text-lg mb-2">{demo.title}</h3>
                <p className="text-gray-300 text-sm">{demo.description}</p>
              </motion.div>
            ))}
          </div>

          {/* Interactive Demo Area */}
          <div className="relative">
            <div className="bg-black/40 backdrop-blur-2xl rounded-3xl border border-white/20 p-8 min-h-[500px]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeDemo}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.5 }}
                >
                  <div className="flex items-center justify-between mb-8">
                    <h3 className="text-2xl font-bold text-white">
                      {demos[activeDemo].title}
                    </h3>
                    <motion.button
                      onClick={playDemo}
                      className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-300"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      disabled={isPlaying}
                    >
                      {isPlaying ? 'Running...' : 'Play Demo'}
                    </motion.button>
                  </div>

                  {/* Process Steps */}
                  <div className="space-y-4 mb-8">
                    {demos[activeDemo].steps.map((step, stepIndex) => (
                      <motion.div
                        key={stepIndex}
                        className={`flex items-center p-4 rounded-xl transition-all duration-500 ${
                          isPlaying && stepIndex <= Math.floor((Date.now() % 5000) / 1000)
                            ? 'bg-green-500/20 border border-green-400/30'
                            : 'bg-white/5 border border-white/10'
                        }`}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: stepIndex * 0.1 }}
                      >
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-4 ${
                          isPlaying && stepIndex <= Math.floor((Date.now() % 5000) / 1000)
                            ? 'bg-green-500 text-white'
                            : 'bg-white/10 text-gray-400'
                        }`}>
                          {stepIndex + 1}
                        </div>
                        <span className="text-white">{step}</span>
                        {isPlaying && stepIndex === Math.floor((Date.now() % 5000) / 1000) && (
                          <motion.div
                            className="ml-auto w-4 h-4 bg-blue-500 rounded-full"
                            animate={{ scale: [1, 1.2, 1] }}
                            transition={{ repeat: Infinity, duration: 1 }}
                          />
                        )}
                      </motion.div>
                    ))}
                  </div>

                  {/* Metrics */}
                  <div className="grid grid-cols-3 gap-4">
                    {Object.entries(demos[activeDemo].metrics).map(([key, value], index) => (
                      <motion.div
                        key={index}
                        className="text-center p-4 bg-white/10 rounded-xl backdrop-blur-sm"
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: index * 0.1 }}
                      >
                        <div className="text-2xl font-bold text-white mb-1">{value}</div>
                        <div className="text-sm text-gray-300">{key}</div>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default InteractiveShowcase;