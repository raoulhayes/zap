import React from 'react';
import { Toaster } from 'react-hot-toast';
import Header from './components/Header-wordpress';
import Footer from './components/Footer';
import GridBackground from './components/GridBackground';
import ThemeProvider from './components/ThemeProvider';
import ChatAssistant from './components/ChatAssistant';
import Scene3D from './components/Scene3D';

// Pages - WordPress version (no routing)
import Home from './pages/Home';

function App() {
  return (
    <ThemeProvider>
      <div className="min-h-screen bg-white dark:bg-gray-900 relative transition-colors duration-500">
        <GridBackground />
        <Scene3D />
        <Header />
        <main className="relative z-10">
          <Home />
        </main>
        <Footer />
        <ChatAssistant />
        <Toaster 
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#363636',
              color: '#fff',
            },
          }}
        />
      </div>
    </ThemeProvider>
  );
}

export default App;