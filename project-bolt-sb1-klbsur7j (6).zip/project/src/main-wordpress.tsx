import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App-wordpress.tsx'
import './index.css'

// WordPress-specific initialization
const initZapAgent = () => {
  const rootElement = document.getElementById('root');
  if (rootElement) {
    const root = ReactDOM.createRoot(rootElement);
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>,
    );
  } else {
    console.error('ZapAgent: Root element not found');
  }
};

// Initialize immediately if DOM is ready, otherwise wait
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initZapAgent);
} else {
  initZapAgent();
}

// Make it globally available for WordPress
(window as any).ZapAgentApp = {
  init: initZapAgent
};