import axios from 'axios';
import { useAuthStore } from '../store/authStore';

const API_BASE_URL = 'https://localhost:3001/api';

const api = axios.create({
  baseURL: API_BASE_URL,
});

// Add auth token to requests
api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      useAuthStore.getState().logout();
    }
    return Promise.reject(error);
  }
);

export default api;

// Auth API
export const authAPI = {
  register: (data: { email: string; password: string; name: string }) =>
    api.post('/auth/register', data),
  login: (data: { email: string; password: string }) =>
    api.post('/auth/login', data),
  logout: () => api.post('/auth/logout'),
  getMe: () => api.get('/auth/me'),
};

// Contact API
export const contactAPI = {
  submit: (data: { name: string; email: string; company?: string; message: string }) =>
    api.post('/contact/submit', data),
};

// Newsletter API
export const newsletterAPI = {
  subscribe: (data: { email: string }) =>
    api.post('/newsletter/subscribe', data),
  unsubscribe: (data: { email: string }) =>
    api.post('/newsletter/unsubscribe', data),
};

// Search API
export const searchAPI = {
  search: (query: string, type?: string) =>
    api.get('/search', { params: { q: query, type } }),
  indexContent: (data: { title: string; content: string; url: string; type: string }) =>
    api.post('/search/index', data),
};

// Comments API
export const commentsAPI = {
  getComments: (pageUrl: string) =>
    api.get('/comments', { params: { page_url: pageUrl } }),
  addComment: (data: { page_url: string; content: string; parent_id?: number }) =>
    api.post('/comments', data),
  deleteComment: (id: number) =>
    api.delete(`/comments/${id}`),
};

// Admin API
export const adminAPI = {
  getStats: () => api.get('/admin/stats'),
  getUsers: () => api.get('/admin/users'),
  getContacts: () => api.get('/admin/contacts'),
  updateContactStatus: (id: number, status: string) =>
    api.patch(`/admin/contacts/${id}`, { status }),
  getSubscribers: () => api.get('/admin/subscribers'),
  getComments: () => api.get('/admin/comments'),
  updateCommentStatus: (id: number, status: string) =>
    api.patch(`/admin/comments/${id}`, { status }),
};