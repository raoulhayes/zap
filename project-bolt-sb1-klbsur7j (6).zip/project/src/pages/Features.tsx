import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const Features = () => {
  const { ref, inView } = useInView({ threshold: 0.1, triggerOnce: true });

  const features = [
    {
      icon: '⚡',
      title: 'Instant Deployment',
      description: 'Deploy AI agents in seconds with our one-click infrastructure. No DevOps required.',
      details: [
        'One-click deployment to production',
        'Auto-scaling infrastructure',
        'Zero downtime updates',
        'Global edge network'
      ]
    },
    {
      icon: '🧠',
      title: 'Advanced AI Models',
      description: 'Powered by the latest GPT-4, Claude, and custom models for maximum intelligence.',
      details: [
        'GPT-4 Turbo integration',
        'Claude 3 Opus support',
        'Custom model training',
        'Multi-modal capabilities'
      ]
    },
    {
      icon: '🔗',
      title: 'Universal Integration',
      description: 'Connect with 2000+ apps through our API-first architecture and pre-built connectors.',
      details: [
        '2000+ pre-built integrations',
        'REST API & GraphQL support',
        'Webhook automation',
        'Custom connector builder'
      ]
    },
    {
      icon: '🛡️',
      title: 'Enterprise Security',
      description: 'SOC 2 Type II compliant with end-to-end encryption and advanced threat protection.',
      details: [
        'SOC 2 Type II certified',
        'End-to-end encryption',
        'Role-based access control',
        'Audit logging'
      ]
    },
    {
      icon: '📊',
      title: 'Real-time Analytics',
      description: 'Monitor performance with comprehensive dashboards and predictive insights.',
      details: [
        'Real-time monitoring',
        'Performance analytics',
        'Predictive insights',
        'Custom dashboards'
      ]
    },
    {
      icon: '🎯',
      title: 'Smart Workflows',
      description: 'Visual workflow builder with AI-powered optimization and automatic error handling.',
      details: [
        'Drag-and-drop builder',
        'AI-powered optimization',
        'Error handling & recovery',
        'Version control'
      ]
    }
  ];

  const useCases = [
    {
      title: 'Customer Support Automation',
      description: 'Reduce response times by 90% with intelligent ticket routing and automated responses.',
      icon: '🎧',
      metrics: ['90% faster responses', '24/7 availability', '95% accuracy'],
      color: 'from-blue-500 to-cyan-500'
    },
    {
      title: 'Sales Lead Qualification',
      description: 'Automatically score, qualify, and route leads to the right sales representatives.',
      icon: '🎯',
      metrics: ['40% more qualified leads', '60% faster processing', '25% higher conversion'],
      color: 'from-green-500 to-emerald-500'
    },
    {
      title: 'Data Processing & Analysis',
      description: 'Transform raw data into actionable insights with automated processing pipelines.',
      icon: '📊',
      metrics: ['10x faster processing', '99.9% accuracy', '70% cost reduction'],
      color: 'from-purple-500 to-pink-500'
    },
    {
      title: 'Content Generation',
      description: 'Generate high-quality content at scale for marketing, documentation, and more.',
      icon: '✍️',
      metrics: ['5x content output', '80% time savings', 'SEO optimized'],
      color: 'from-orange-500 to-red-500'
    }
  ];

  return (
    <div className="min-h-screen pt-24 pb-20 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-gray-800 transition-colors duration-500">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          ref={ref}
          className="text-center mb-20"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            Powerful
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Features</span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Everything you need to build, deploy, and scale intelligent automation agents
          </p>
        </motion.div>

        {/* Core Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className="bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all duration-300"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              <div className="text-4xl mb-6">{feature.icon}</div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">{feature.title}</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">{feature.description}</p>
              
              <ul className="space-y-2">
                {feature.details.map((detail, detailIndex) => (
                  <li key={detailIndex} className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mr-3 flex-shrink-0" />
                    {detail}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Use Cases Section */}
        <motion.div
          className="mb-20"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-6">
              Real-World
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Use Cases</span>
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              See how businesses are transforming their operations with ZapAgent AI
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {useCases.map((useCase, index) => (
              <motion.div
                key={index}
                className="bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all duration-300 group"
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 1 + index * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <div className="flex items-center mb-6">
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${useCase.color} flex items-center justify-center text-2xl mr-4 group-hover:scale-110 transition-transform`}>
                    {useCase.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white">{useCase.title}</h3>
                  </div>
                </div>
                
                <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                  {useCase.description}
                </p>

                <div className="grid grid-cols-1 gap-3">
                  {useCase.metrics.map((metric, metricIndex) => (
                    <div key={metricIndex} className="flex items-center">
                      <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${useCase.color} mr-3`} />
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{metric}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* CTA Section */}
        <motion.div
          className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl p-12 text-center text-white"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 1.4 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Join thousands of companies already using ZapAgent AI to transform their operations
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <motion.button
              className="bg-white text-gray-900 px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-all duration-200"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Start Free Trial
            </motion.button>
            <motion.button
              className="border-2 border-white/30 text-white px-8 py-4 rounded-xl font-semibold hover:bg-white/10 transition-all duration-200"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Schedule Demo
            </motion.button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Features;