import React from 'react';
import Hero from '../components/Hero';
import Features from '../components/Features';
import TechShowcase from '../components/TechShowcase';
import ProductDemo from '../components/ProductDemo';
import TrustSignals from '../components/TrustSignals';
import Testimonials from '../components/Testimonials';
import Pricing from '../components/Pricing';
import CTA from '../components/CTA';

const Home = () => {
  return (
    <>
      <Hero />
      <Features />
      <TechShowcase />
      <ProductDemo />
      <TrustSignals />
      <Testimonials />
      <Pricing />
      <CTA />
    </>
  );
};

export default Home;