import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { contactAPI, newsletterAPI } from '../services/api';
import { MicroButton } from '../components/MicroInteractions';

interface ContactForm {
  name: string;
  email: string;
  company?: string;
  message: string;
}

interface NewsletterForm {
  email: string;
}

const Contact = () => {
  const { ref, inView } = useInView({ threshold: 0.1, triggerOnce: true });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubscribing, setIsSubscribing] = useState(false);

  const { register: registerContact, handleSubmit: handleContactSubmit, formState: { errors: contactErrors }, reset: resetContact } = useForm<ContactForm>();
  const { register: registerNewsletter, handleSubmit: handleNewsletterSubmit, formState: { errors: newsletterErrors }, reset: resetNewsletter } = useForm<NewsletterForm>();

  const onContactSubmit = async (data: ContactForm) => {
    setIsSubmitting(true);
    try {
      await contactAPI.submit(data);
      toast.success('Message sent successfully! We\'ll get back to you soon.');
      resetContact();
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Failed to send message');
    } finally {
      setIsSubmitting(false);
    }
  };

  const onNewsletterSubmit = async (data: NewsletterForm) => {
    setIsSubscribing(true);
    try {
      await newsletterAPI.subscribe(data);
      toast.success('Successfully subscribed to our newsletter!');
      resetNewsletter();
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Failed to subscribe');
    } finally {
      setIsSubscribing(false);
    }
  };

  const contactMethods = [
    {
      icon: '📧',
      title: 'Email',
      description: 'Send us an email anytime',
      contact: 'hello@zapagent.ai',
      action: 'mailto:hello@zapagent.ai'
    },
    {
      icon: '📞',
      title: 'Phone',
      description: 'Call us during business hours',
      contact: '+1 (555) 123-4567',
      action: 'tel:+15551234567'
    },
    {
      icon: '💬',
      title: 'Live Chat',
      description: 'Chat with our support team',
      contact: 'Available 24/7',
      action: '#'
    },
    {
      icon: '📍',
      title: 'Office',
      description: 'Visit our headquarters',
      contact: 'San Francisco, CA',
      action: '#'
    }
  ];

  const offices = [
    {
      city: 'San Francisco',
      address: '123 Innovation Drive\nSan Francisco, CA 94105',
      phone: '+1 (555) 123-4567',
      email: 'sf@zapagent.ai'
    },
    {
      city: 'New York',
      address: '456 Tech Avenue\nNew York, NY 10001',
      phone: '+1 (555) 987-6543',
      email: 'ny@zapagent.ai'
    },
    {
      city: 'London',
      address: '789 AI Street\nLondon, UK EC1A 1BB',
      phone: '+44 20 1234 5678',
      email: 'london@zapagent.ai'
    }
  ];

  return (
    <div className="min-h-screen pt-24 pb-20 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-gray-800 transition-colors duration-500">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          ref={ref}
          className="text-center mb-20"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            Get in
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Touch</span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Ready to transform your business with AI automation? Let's talk about your needs.
          </p>
        </motion.div>

        {/* Contact Methods */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {contactMethods.map((method, index) => (
            <motion.a
              key={index}
              href={method.action}
              className="bg-white dark:bg-gray-900 rounded-2xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all duration-300 group block"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              <div className="text-3xl mb-4 group-hover:scale-110 transition-transform">{method.icon}</div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">{method.title}</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm mb-2">{method.description}</p>
              <p className="text-blue-600 dark:text-blue-400 font-medium">{method.contact}</p>
            </motion.a>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
          {/* Contact Form */}
          <motion.div
            className="bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-sm border border-gray-200 dark:border-gray-700"
            initial={{ opacity: 0, x: -20 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Send us a message</h2>
            <form onSubmit={handleContactSubmit(onContactSubmit)} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Name *
                </label>
                <input
                  type="text"
                  {...registerContact('name', { required: 'Name is required' })}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  placeholder="Enter your name"
                />
                {contactErrors.name && (
                  <p className="text-red-500 text-sm mt-1">{contactErrors.name.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Email *
                </label>
                <input
                  type="email"
                  {...registerContact('email', { required: 'Email is required' })}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  placeholder="Enter your email"
                />
                {contactErrors.email && (
                  <p className="text-red-500 text-sm mt-1">{contactErrors.email.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Company
                </label>
                <input
                  type="text"
                  {...registerContact('company')}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  placeholder="Enter your company name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Message *
                </label>
                <textarea
                  {...registerContact('message', { required: 'Message is required' })}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white resize-none"
                  placeholder="Tell us about your project..."
                />
                {contactErrors.message && (
                  <p className="text-red-500 text-sm mt-1">{contactErrors.message.message}</p>
                )}
              </div>

              <motion.button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-6 rounded-xl font-semibold hover:shadow-lg transition-all duration-300 disabled:opacity-50"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                {isSubmitting ? 'Sending...' : 'Send Message'}
              </motion.button>
            </form>
          </motion.div>

          {/* Contact Info & Demo */}
          <motion.div
            className="space-y-8"
            initial={{ opacity: 0, x: 20 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-2xl p-8 border border-blue-100 dark:border-blue-800/30">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Book a Demo</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                See ZapAgent AI in action with a personalized demo tailored to your use case.
              </p>
              <MicroButton href="https://calendly.com/zapagentai/ai-automation-needs-assesment?month=2025-06">
                Schedule Demo
              </MicroButton>
            </div>

            {/* Newsletter Signup */}
            <div className="bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-sm border border-gray-200 dark:border-gray-700">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Stay Updated</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Get the latest updates on AI automation and product releases.
              </p>
              <form onSubmit={handleNewsletterSubmit(onNewsletterSubmit)} className="space-y-4">
                <div>
                  <input
                    type="email"
                    {...registerNewsletter('email', { required: 'Email is required' })}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                    placeholder="Enter your email"
                  />
                  {newsletterErrors.email && (
                    <p className="text-red-500 text-sm mt-1">{newsletterErrors.email.message}</p>
                  )}
                </div>
                <motion.button
                  type="submit"
                  disabled={isSubscribing}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-6 rounded-xl font-semibold hover:shadow-lg transition-all duration-300 disabled:opacity-50"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {isSubscribing ? 'Subscribing...' : 'Subscribe'}
                </motion.button>
              </form>
            </div>
          </motion.div>
        </div>

        {/* Office Locations */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Our Offices
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-300">
              Visit us at one of our global locations
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {offices.map((office, index) => (
              <motion.div
                key={index}
                className="bg-white dark:bg-gray-900 rounded-2xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-all duration-300"
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.7 + index * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">{office.city}</h3>
                <div className="space-y-3 text-gray-600 dark:text-gray-300">
                  <div className="flex items-start">
                    <span className="text-blue-600 dark:text-blue-400 mr-2">📍</span>
                    <span className="whitespace-pre-line">{office.address}</span>
                  </div>
                  <div className="flex items-center">
                    <span className="text-blue-600 dark:text-blue-400 mr-2">📞</span>
                    <span>{office.phone}</span>
                  </div>
                  <div className="flex items-center">
                    <span className="text-blue-600 dark:text-blue-400 mr-2">📧</span>
                    <span>{office.email}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Contact;