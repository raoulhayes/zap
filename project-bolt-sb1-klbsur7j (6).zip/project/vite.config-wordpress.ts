import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// WordPress-specific Vite configuration
export default defineConfig({
  plugins: [react()],
  base: './', // Use relative paths for WordPress
  build: {
    outDir: 'dist-wordpress',
    assetsDir: 'assets',
    rollupOptions: {
      output: {
        // Ensure consistent file names for WordPress integration
        entryFileNames: 'assets/zapagent-[name].js',
        chunkFileNames: 'assets/zapagent-[name].js',
        assetFileNames: 'assets/zapagent-[name].[ext]',
        // Ensure all code is in a single bundle for WordPress
        manualChunks: undefined
      }
    },
    // Ensure compatibility with WordPress
    target: 'es2015',
    minify: 'terser'
  },
  define: {
    // Disable React Router for WordPress
    'process.env.WORDPRESS_MODE': JSON.stringify('true')
  }
})