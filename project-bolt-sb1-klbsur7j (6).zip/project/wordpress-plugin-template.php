<?php
/**
 * Plugin Name: ZapAgent AI Landing Page
 * Description: ZapAgent AI homepage integration for WordPress
 * Version: 1.0.0
 * Author: ZapAgent AI
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class ZapAgentLandingPage {
    
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        add_shortcode('zapagent_landing', array($this, 'render_landing_page'));
        add_action('wp_ajax_zapagent_contact', array($this, 'handle_contact_form'));
        add_action('wp_ajax_nopriv_zapagent_contact', array($this, 'handle_contact_form'));
    }
    
    public function enqueue_assets() {
        // Enqueue the built CSS and JS files
        wp_enqueue_style(
            'zapagent-styles',
            plugin_dir_url(__FILE__) . 'dist-wordpress/assets/zapagent-[hash].css',
            array(),
            '1.0.0'
        );
        
        wp_enqueue_script(
            'zapagent-scripts',
            plugin_dir_url(__FILE__) . 'dist-wordpress/assets/zapagent-[hash].js',
            array(),
            '1.0.0',
            true
        );
        
        // Localize script for WordPress AJAX
        wp_localize_script('zapagent-scripts', 'zapagent_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('zapagent_nonce')
        ));
    }
    
    public function render_landing_page($atts) {
        ob_start();
        ?>
        <div id="zapagent-root"></div>
        <script>
            // Initialize the React app
            document.addEventListener('DOMContentLoaded', function() {
                if (window.ZapAgentApp) {
                    window.ZapAgentApp.init();
                }
            });
        </script>
        <?php
        return ob_get_clean();
    }
    
    public function handle_contact_form() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'zapagent_nonce')) {
            wp_die('Security check failed');
        }
        
        // Handle contact form submission
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $company = sanitize_text_field($_POST['company']);
        $message = sanitize_textarea_field($_POST['message']);
        
        // Save to WordPress database or send email
        // Implementation depends on your requirements
        
        wp_send_json_success(array('message' => 'Contact form submitted successfully'));
    }
}

// Initialize the plugin
new ZapAgentLandingPage();

// Create custom page template
function zapagent_create_landing_page() {
    $page_title = 'ZapAgent AI';
    $page_content = '[zapagent_landing]';
    
    // Check if page already exists
    $page = get_page_by_title($page_title);
    
    if (!$page) {
        // Create the page
        $page_data = array(
            'post_title' => $page_title,
            'post_content' => $page_content,
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_slug' => 'zapagent-ai'
        );
        
        wp_insert_post($page_data);
    }
}

// Activate hook
register_activation_hook(__FILE__, 'zapagent_create_landing_page');
?>