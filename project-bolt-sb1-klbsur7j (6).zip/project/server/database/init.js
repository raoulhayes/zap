import sqlite3 from 'sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const dbPath = process.env.DATABASE_URL || join(__dirname, '../../database.sqlite');

export const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Error opening database:', err);
  } else {
    console.log('Connected to SQLite database');
  }
});

export const initDatabase = async () => {
  return new Promise((resolve, reject) => {
    let completedOperations = 0;
    const totalOperations = 6; // 5 table creations + 1 admin user creation + search content

    const checkComplete = () => {
      completedOperations++;
      if (completedOperations === totalOperations) {
        resolve();
      }
    };

    // Users table
    db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        name TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `, (err) => {
      if (err) reject(err);
      else checkComplete();
    });

    // Contact submissions table
    db.run(`
      CREATE TABLE IF NOT EXISTS contact_submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        company TEXT,
        message TEXT NOT NULL,
        status TEXT DEFAULT 'new',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `, (err) => {
      if (err) reject(err);
      else checkComplete();
    });

    // Newsletter subscriptions table
    db.run(`
      CREATE TABLE IF NOT EXISTS newsletter_subscriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        status TEXT DEFAULT 'active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `, (err) => {
      if (err) reject(err);
      else checkComplete();
    });

    // Comments table
    db.run(`
      CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        page_url TEXT NOT NULL,
        content TEXT NOT NULL,
        parent_id INTEGER,
        status TEXT DEFAULT 'approved',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id),
        FOREIGN KEY (parent_id) REFERENCES comments (id)
      )
    `, (err) => {
      if (err) reject(err);
      else checkComplete();
    });

    // Search content table for indexing
    db.run(`
      CREATE TABLE IF NOT EXISTS search_content (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        url TEXT NOT NULL,
        type TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `, (err) => {
      if (err) reject(err);
      else checkComplete();
    });

    // Create default admin user
    (async () => {
      try {
        const bcrypt = await import('bcryptjs');
        const hashedPassword = await bcrypt.hash('admin123', 10);
        
        db.run(`
          INSERT OR IGNORE INTO users (email, password, name, role)
          VALUES (?, ?, ?, ?)
        `, ['admin@zapagent.ai', hashedPassword, 'Admin User', 'admin'], (err) => {
          if (err) reject(err);
          else {
            // Populate search content after admin user is created
            populateSearchContent(() => {
              checkComplete();
            });
          }
        });
      } catch (error) {
        reject(error);
      }
    })();
  });
};

const populateSearchContent = (callback) => {
  const searchData = [
    {
      title: 'ZapAgent AI - AI Automation Platform',
      content: 'Deploy intelligent automation agents that handle complex workflows, make decisions, and scale your operations without human intervention.',
      url: '/',
      type: 'page'
    },
    {
      title: 'Features - AI Automation Tools',
      content: 'Instant deployment, advanced AI models, universal integration, enterprise security, real-time analytics, smart workflows',
      url: '/features',
      type: 'page'
    },
    {
      title: 'Pricing - AI Automation Plans',
      content: 'Starter plan $29/month, Professional plan $99/month, Enterprise custom pricing. All plans include AI agents, API calls, integrations',
      url: '/pricing',
      type: 'page'
    },
    {
      title: 'Contact - Get in Touch',
      content: 'Contact ZapAgent AI for AI automation solutions, demos, and support. Email hello@zapagent.ai',
      url: '/contact',
      type: 'page'
    }
  ];

  let completed = 0;
  const total = searchData.length;

  searchData.forEach(item => {
    db.run(`
      INSERT OR REPLACE INTO search_content (title, content, url, type)
      VALUES (?, ?, ?, ?)
    `, [item.title, item.content, item.url, item.type], () => {
      completed++;
      if (completed === total && callback) {
        callback();
      }
    });
  });
};