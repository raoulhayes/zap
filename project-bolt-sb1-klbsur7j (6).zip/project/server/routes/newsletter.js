import express from 'express';
import nodemailer from 'nodemailer';
import { db } from '../database/init.js';

const router = express.Router();

// Configure email transporter
const transporter = nodemailer.createTransporter({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

// Subscribe to newsletter
router.post('/subscribe', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    // Check if already subscribed
    db.get(
      'SELECT id FROM newsletter_subscriptions WHERE email = ?',
      [email],
      async (err, row) => {
        if (err) {
          return res.status(500).json({ error: 'Database error' });
        }

        if (row) {
          return res.status(400).json({ error: 'Email already subscribed' });
        }

        // Add subscription
        db.run(
          'INSERT INTO newsletter_subscriptions (email) VALUES (?)',
          [email],
          async function(err) {
            if (err) {
              return res.status(500).json({ error: 'Failed to subscribe' });
            }

            // Send welcome email
            try {
              await transporter.sendMail({
                from: process.env.SMTP_USER,
                to: email,
                subject: 'Welcome to ZapAgent AI Newsletter',
                html: `
                  <h2>Welcome to ZapAgent AI!</h2>
                  <p>Thank you for subscribing to our newsletter.</p>
                  <p>You'll receive the latest updates on AI automation, product releases, and industry insights.</p>
                  <p>Best regards,<br>The ZapAgent AI Team</p>
                `,
              });
            } catch (emailError) {
              console.error('Email error:', emailError);
            }

            res.status(201).json({
              message: 'Successfully subscribed to newsletter',
              id: this.lastID
            });
          }
        );
      }
    );
  } catch (error) {
    console.error('Newsletter subscription error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Unsubscribe from newsletter
router.post('/unsubscribe', (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    db.run(
      'UPDATE newsletter_subscriptions SET status = ? WHERE email = ?',
      ['unsubscribed', email],
      function(err) {
        if (err) {
          return res.status(500).json({ error: 'Database error' });
        }

        if (this.changes === 0) {
          return res.status(404).json({ error: 'Email not found' });
        }

        res.json({ message: 'Successfully unsubscribed' });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;