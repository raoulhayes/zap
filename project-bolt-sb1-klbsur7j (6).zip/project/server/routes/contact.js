import express from 'express';
import nodemailer from 'nodemailer';
import { db } from '../database/init.js';

const router = express.Router();

// Configure email transporter
const transporter = nodemailer.createTransporter({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

// Submit contact form
router.post('/submit', async (req, res) => {
  try {
    const { name, email, company, message } = req.body;

    if (!name || !email || !message) {
      return res.status(400).json({ error: 'Name, email, and message are required' });
    }

    // Save to database
    db.run(
      'INSERT INTO contact_submissions (name, email, company, message) VALUES (?, ?, ?, ?)',
      [name, email, company || null, message],
      async function(err) {
        if (err) {
          console.error('Database error:', err);
          return res.status(500).json({ error: 'Failed to save contact submission' });
        }

        // Send email notification
        try {
          await transporter.sendMail({
            from: process.env.SMTP_USER,
            to: 'hello@zapagent.ai',
            subject: 'New Contact Form Submission',
            html: `
              <h2>New Contact Form Submission</h2>
              <p><strong>Name:</strong> ${name}</p>
              <p><strong>Email:</strong> ${email}</p>
              <p><strong>Company:</strong> ${company || 'Not provided'}</p>
              <p><strong>Message:</strong></p>
              <p>${message}</p>
            `,
          });

          // Send auto-reply
          await transporter.sendMail({
            from: process.env.SMTP_USER,
            to: email,
            subject: 'Thank you for contacting ZapAgent AI',
            html: `
              <h2>Thank you for your message!</h2>
              <p>Hi ${name},</p>
              <p>We've received your message and will get back to you within 24 hours.</p>
              <p>Best regards,<br>The ZapAgent AI Team</p>
            `,
          });
        } catch (emailError) {
          console.error('Email error:', emailError);
          // Don't fail the request if email fails
        }

        res.status(201).json({
          message: 'Contact form submitted successfully',
          id: this.lastID
        });
      }
    );
  } catch (error) {
    console.error('Contact form error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;