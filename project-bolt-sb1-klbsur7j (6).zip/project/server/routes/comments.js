import express from 'express';
import { db } from '../database/init.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Get comments for a page
router.get('/', (req, res) => {
  try {
    const { page_url } = req.query;

    if (!page_url) {
      return res.status(400).json({ error: 'Page URL is required' });
    }

    db.all(`
      SELECT c.*, u.name as user_name, u.email as user_email
      FROM comments c
      LEFT JOIN users u ON c.user_id = u.id
      WHERE c.page_url = ? AND c.status = 'approved'
      ORDER BY c.created_at DESC
    `, [page_url], (err, rows) => {
      if (err) {
        return res.status(500).json({ error: 'Database error' });
      }

      res.json({ comments: rows });
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Add a comment
router.post('/', authenticateToken, (req, res) => {
  try {
    const { page_url, content, parent_id } = req.body;

    if (!page_url || !content) {
      return res.status(400).json({ error: 'Page URL and content are required' });
    }

    db.run(
      'INSERT INTO comments (user_id, page_url, content, parent_id) VALUES (?, ?, ?, ?)',
      [req.user.userId, page_url, content, parent_id || null],
      function(err) {
        if (err) {
          return res.status(500).json({ error: 'Failed to add comment' });
        }

        res.status(201).json({
          message: 'Comment added successfully',
          id: this.lastID
        });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete a comment
router.delete('/:id', authenticateToken, (req, res) => {
  try {
    const { id } = req.params;

    // Check if user owns the comment or is admin
    db.get(
      'SELECT user_id FROM comments WHERE id = ?',
      [id],
      (err, comment) => {
        if (err) {
          return res.status(500).json({ error: 'Database error' });
        }

        if (!comment) {
          return res.status(404).json({ error: 'Comment not found' });
        }

        if (comment.user_id !== req.user.userId && req.user.role !== 'admin') {
          return res.status(403).json({ error: 'Not authorized' });
        }

        db.run('DELETE FROM comments WHERE id = ?', [id], function(err) {
          if (err) {
            return res.status(500).json({ error: 'Failed to delete comment' });
          }

          res.json({ message: 'Comment deleted successfully' });
        });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;