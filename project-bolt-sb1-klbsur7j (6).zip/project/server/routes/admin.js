import express from 'express';
import { db } from '../database/init.js';
import { authenticateToken, requireAdmin } from '../middleware/auth.js';

const router = express.Router();

// Get dashboard stats
router.get('/stats', authenticateToken, requireAdmin, (req, res) => {
  try {
    const stats = {};

    // Get user count
    db.get('SELECT COUNT(*) as count FROM users', (err, result) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      stats.users = result.count;

      // Get contact submissions count
      db.get('SELECT COUNT(*) as count FROM contact_submissions', (err, result) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        stats.contacts = result.count;

        // Get newsletter subscriptions count
        db.get('SELECT COUNT(*) as count FROM newsletter_subscriptions WHERE status = "active"', (err, result) => {
          if (err) return res.status(500).json({ error: 'Database error' });
          stats.subscribers = result.count;

          // Get comments count
          db.get('SELECT COUNT(*) as count FROM comments', (err, result) => {
            if (err) return res.status(500).json({ error: 'Database error' });
            stats.comments = result.count;

            res.json(stats);
          });
        });
      });
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all users
router.get('/users', authenticateToken, requireAdmin, (req, res) => {
  try {
    db.all(
      'SELECT id, email, name, role, created_at FROM users ORDER BY created_at DESC',
      (err, rows) => {
        if (err) {
          return res.status(500).json({ error: 'Database error' });
        }
        res.json({ users: rows });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all contact submissions
router.get('/contacts', authenticateToken, requireAdmin, (req, res) => {
  try {
    db.all(
      'SELECT * FROM contact_submissions ORDER BY created_at DESC',
      (err, rows) => {
        if (err) {
          return res.status(500).json({ error: 'Database error' });
        }
        res.json({ contacts: rows });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Update contact submission status
router.patch('/contacts/:id', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!status) {
      return res.status(400).json({ error: 'Status is required' });
    }

    db.run(
      'UPDATE contact_submissions SET status = ? WHERE id = ?',
      [status, id],
      function(err) {
        if (err) {
          return res.status(500).json({ error: 'Database error' });
        }

        if (this.changes === 0) {
          return res.status(404).json({ error: 'Contact submission not found' });
        }

        res.json({ message: 'Status updated successfully' });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all newsletter subscriptions
router.get('/subscribers', authenticateToken, requireAdmin, (req, res) => {
  try {
    db.all(
      'SELECT * FROM newsletter_subscriptions ORDER BY created_at DESC',
      (err, rows) => {
        if (err) {
          return res.status(500).json({ error: 'Database error' });
        }
        res.json({ subscribers: rows });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all comments
router.get('/comments', authenticateToken, requireAdmin, (req, res) => {
  try {
    db.all(`
      SELECT c.*, u.name as user_name, u.email as user_email
      FROM comments c
      LEFT JOIN users u ON c.user_id = u.id
      ORDER BY c.created_at DESC
    `, (err, rows) => {
      if (err) {
        return res.status(500).json({ error: 'Database error' });
      }
      res.json({ comments: rows });
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Update comment status
router.patch('/comments/:id', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!status) {
      return res.status(400).json({ error: 'Status is required' });
    }

    db.run(
      'UPDATE comments SET status = ? WHERE id = ?',
      [status, id],
      function(err) {
        if (err) {
          return res.status(500).json({ error: 'Database error' });
        }

        if (this.changes === 0) {
          return res.status(404).json({ error: 'Comment not found' });
        }

        res.json({ message: 'Comment status updated successfully' });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;