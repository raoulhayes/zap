import express from 'express';
import { db } from '../database/init.js';

const router = express.Router();

// Search content
router.get('/', (req, res) => {
  try {
    const { q, type } = req.query;

    if (!q) {
      return res.status(400).json({ error: 'Search query is required' });
    }

    let query = `
      SELECT * FROM search_content 
      WHERE title LIKE ? OR content LIKE ?
    `;
    let params = [`%${q}%`, `%${q}%`];

    if (type) {
      query += ' AND type = ?';
      params.push(type);
    }

    query += ' ORDER BY title ASC LIMIT 20';

    db.all(query, params, (err, rows) => {
      if (err) {
        return res.status(500).json({ error: 'Database error' });
      }

      res.json({
        query: q,
        results: rows,
        count: rows.length
      });
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Add content to search index
router.post('/index', (req, res) => {
  try {
    const { title, content, url, type } = req.body;

    if (!title || !content || !url || !type) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    db.run(
      'INSERT OR REPLACE INTO search_content (title, content, url, type) VALUES (?, ?, ?, ?)',
      [title, content, url, type],
      function(err) {
        if (err) {
          return res.status(500).json({ error: 'Failed to index content' });
        }

        res.status(201).json({
          message: 'Content indexed successfully',
          id: this.lastID
        });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;