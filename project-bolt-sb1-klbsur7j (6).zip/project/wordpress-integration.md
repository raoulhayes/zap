# WordPress Integration Guide

## Files to Upload to WordPress

After running `npm run build`, you'll find these files in the `dist/` folder:

### Required Files:
1. `index.html` - Main HTML file
2. `assets/index-[hash].js` - JavaScript bundle
3. `assets/index-[hash].css` - CSS bundle
4. `Logo-150x150.jpeg` - Logo image

## WordPress Integration Steps:

### Method 1: Custom Page Template
1. Create a new page template in your WordPress theme
2. Copy the content from `dist/index.html`
3. Upload CSS and JS files to your theme's assets folder
4. Enqueue the assets in your theme's functions.php

### Method 2: Plugin Integration
1. Create a custom plugin
2. Enqueue the built assets
3. Use shortcodes or hooks to display the content

## Important Notes:

### WordPress Compatibility Issues to Address:
1. **React Router**: WordPress uses its own routing, so we need to disable React Router for WordPress
2. **API Endpoints**: Update API base URL to match your WordPress site
3. **Asset Paths**: Ensure all asset paths are absolute or properly configured
4. **WordPress Admin Bar**: Account for WordPress admin bar spacing

### Recommended Approach:
Use the static build files and integrate them as a custom page template or landing page plugin.